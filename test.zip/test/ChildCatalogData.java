package com.costco.mobile.bff.homepage.domain.entity.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChildCatalogData {

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String id;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isPublished;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isBuyable;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isFsa;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isDispOnZeroInv;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer backorderableType;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer backorderQuantity;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isChd;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private DisplayPrice displayPrice;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<ProductAttribute> productAttributes;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Assets assets;
}
