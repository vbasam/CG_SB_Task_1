package com.costco.mobile.bff.homepage.domain.entity.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttributeObj {
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String key;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String value;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String type;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public Boolean isPills;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String identifier;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public String swatchImage;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public Boolean isDisplayable;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    public Integer displaySequence;
}
