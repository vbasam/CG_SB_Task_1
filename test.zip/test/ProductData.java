package com.costco.mobile.bff.homepage.domain.entity.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductData {

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String id;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<String> programTypes;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isPublished;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isBuyable;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer ratingScore;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer ratingCount;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer dispPriceInCartOnly;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isEligibleForReviews;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isFsa;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isLinkFeeEligible;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isMembershipReqd;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String productClassType;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isDispOnZeroInv;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer backorderableType;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Integer backorderQuantity;
    private String maxItemOrderQty;
    private String minItemOrderQty;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Boolean isChd;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<Descriptions> descriptions;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private DisplayPrice displayPrice;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<ProductAttribute> productAttributes;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Assets assets;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<ChildCatalogData> childCatalogData;

}
