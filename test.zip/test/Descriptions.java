package com.costco.mobile.bff.homepage.domain.entity.summary;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Descriptions {
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String languageKey;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Description description;
}
